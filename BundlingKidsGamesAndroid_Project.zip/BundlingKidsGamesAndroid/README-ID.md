# Bundling Kids Games — Proyek Android WebView

Proyek Android Studio dasar untuk membungkus menu HTML Bundling Kids Games ke dalam APK.

## Isi
- `app/src/main/assets/index.html`: menu HTML yang disertakan di dalam APK.
- `MainActivity.kt`: WebView untuk menampilkan menu lokal; tautan HTTP/HTTPS dibuka di browser.
- Gradle project files untuk dibuka melalui Android Studio.

## Cara membuat APK
1. Ekstrak ZIP.
2. Buka Android Studio → **Open** → pilih folder `BundlingKidsGamesAndroid`.
3. Tunggu Gradle Sync selesai. Android Studio mungkin perlu mengunduh Android SDK/build tools.
4. Pilih **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Setelah selesai, tekan tautan **locate** pada notifikasi build. APK debug biasanya ada di `app/build/outputs/apk/debug/app-debug.apk`.
6. Pindahkan APK ke HP Android dan instal. Jika diminta, izinkan pemasangan dari sumber tersebut.

## Batasan penting
- Menu HTML disertakan lokal, jadi menu dapat dibuka tanpa internet.
- Lima tautan game saat ini menuju Canva, sehingga konten game itu sendiri masih memerlukan internet.
- Agar seluruh permainan benar-benar offline, diperlukan kode sumber HTML/CSS/JavaScript dan semua gambar/audio lokal untuk tiap game; lalu tautan Canva perlu diganti dengan halaman lokal di folder assets.
- Proyek ini adalah sumber proyek Android, bukan file APK yang sudah dibangun.
